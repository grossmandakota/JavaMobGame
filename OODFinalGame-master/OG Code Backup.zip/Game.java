/**
 *  This class is the main class of the "World of Zuul" application. 
 *  "World of Zuul" is a very simple, text based adventure game.  Users 
 *  can walk around some scenery. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.
 * 
 * @author  Michael Kolling and David J. Barnes modified by Rodrigo A. Obando (2018)
 * @version 1.1 (December 2002)
 */

class Game 
{
    private Parser parser; // reading commands from the user 
    private Player player;

    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        player = new Player(GameWorld.getInstance().getEntrance());
        parser = new Parser();
    }
    
    public Room createWorld()
    {
        Room outside = new Room("outside the main entrance of the university");
        Room cctparking = new Room("in the parking lot at CCT");
        Room boulevard = new Room("on the boulevard");
        Room universityParking = new Room("in the parking lot at University Hall");
        Room parkingDeck = new Room("in the parking deck");
        Room cct = new Room("in the CCT building");
        Room theGreen = new Room("in the green in from of Schuster Center");
        Room universityHall = new Room("in University Hall");
        Room schuster = new Room("in the Schuster Center");

        outside.setExit("west", boulevard);

        boulevard.setExit("east", outside);
        boulevard.setExit("south", cctparking);
        boulevard.setExit("west", theGreen);
        boulevard.setExit("north", universityParking);

        cctparking.setExit("west", cct);
        cctparking.setExit("north", boulevard);

        cct.setExit("east", cctparking);
        cct.setExit("north", schuster);

        schuster.setExit("south", cct);
        schuster.setExit("north", universityHall);
        schuster.setExit("east", theGreen);

        theGreen.setExit("west", schuster);
        theGreen.setExit("east", boulevard);

        universityHall.setExit("south", schuster);
        universityHall.setExit("east", universityParking);

        universityParking.setExit("south", boulevard);
        universityParking.setExit("west", universityHall);
        universityParking.setExit("north", parkingDeck);

        parkingDeck.setExit("south", universityParking);

        return outside;
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play() 
    {            
        printWelcome();
        
        // if you want to manually start in a certain room
        // Command tempCommand = new GoCommand();
        // tempCommand.setSecondWord("west");
        // tempCommand.execute(player);
        
        //if you made the funtion pasreString in parser
        //parser.parseString("go west").execute(player);
        
        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.
                
        boolean finished = false;
        while(! finished) {
            Command command = parser.getCommand();
            if(command == null) {
                System.out.println("I don't understand...");
            } else {
                finished = command.execute(player);  // quit return true
            }
        }
        System.out.println("Thank you for playing.  Good bye.");
    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to the World of CSU!");
        System.out.println(" The World of CSU is a new, incredibly boring adventure game.");
        System.out.println("\nType 'help' if you need help.");
        System.out.println();
        System.out.println(player.getCurrentRoom().getLongDescription());
    }
}

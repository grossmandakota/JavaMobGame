
/**
 * Write a description of class GameWorld here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GameWorld
{
    private static GameWorld instance;
    private Room entrance;
    
    /**
     * Constructor for objects of class GameWorld
     */
    // this way you can only create a gameWorld here
    private GameWorld()
    {
        entrance = createWorld();
    }
    
    public Room getEntrance()
    {
        return entrance;
    }
    
    public static GameWorld getInstance()
    {
        if(instance == null)
        {
            instance = new GameWorld();
        }
        return instance;
    }
    
    private Room createWorld()
    {
        Room outside = new Room("outside the main entrance of the university");
        Room cctparking = new Room("in the parking lot at CCT");
        Room boulevard = new Room("on the boulevard");
        Room universityParking = new Room("in the parking lot at University Hall");
        Room parkingDeck = new Room("in the parking deck");
        Room cct = new Room("in the CCT building");
        Room theGreen = new Room("in the green in from of Schuster Center");
        Room universityHall = new Room("in University Hall");
        Room schuster = new Room("in the Schuster Center");

        outside.setExit("west", boulevard);

        boulevard.setExit("east", outside);
        boulevard.setExit("south", cctparking);
        boulevard.setExit("west", theGreen);
        boulevard.setExit("north", universityParking);

        cctparking.setExit("west", cct);
        cctparking.setExit("north", boulevard);

        cct.setExit("east", cctparking);
        cct.setExit("north", schuster);

        schuster.setExit("south", cct);
        schuster.setExit("north", universityHall);
        schuster.setExit("east", theGreen);

        theGreen.setExit("west", schuster);
        theGreen.setExit("east", boulevard);

        universityHall.setExit("south", schuster);
        universityHall.setExit("east", universityParking);

        universityParking.setExit("south", boulevard);
        universityParking.setExit("west", universityHall);
        universityParking.setExit("north", parkingDeck);

        parkingDeck.setExit("south", universityParking);

        return outside;
    }
    
}

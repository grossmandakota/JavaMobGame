
/**
 * Write a description of class SellCommand here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SellCommand extends Command
{
    private CommandWords commandWords;

    public SellCommand()
    {
        super("sell");
    }

    public boolean execute(Player player)
    {
        // what do we sell
        return false;
    }
}
